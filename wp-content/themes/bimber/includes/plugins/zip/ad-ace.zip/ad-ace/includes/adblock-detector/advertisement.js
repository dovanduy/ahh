/**
 * if adblock is active, this file will be blocked
 * so $.adblock is not defined
 */

jQuery.adblock = false;